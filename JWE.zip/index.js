const express = require("express");
const cors = require('cors');
const authRouter = require("./routes/authRoute");

const app = express();
app.use(express.json());
app.use(cors({
  origin: '*',
  methods: ['GET','POST','DELETE','UPDATE','PUT','PATCH']
}));

app.use('/',  authRouter);

const port = 8001;

app.listen(port, () => {
  console.log(`App running on port ${port}...`);
});
