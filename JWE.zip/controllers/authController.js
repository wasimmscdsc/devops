const jwt = require('node-webtokens');
const AppError = require('./../utils/apiError');

const convertHexToSignedByteArray = (str) => {
    const hexChar = str.split("");
    const hexLength = hexChar.length;
  
    const hexByteArray = new Int8Array(hexLength >> 1);
  
    for (let i = 0, j = 0; j < hexLength; i++) {
      let hexDigit = GetHexDigit(hexChar[j]) << 4;
      j++;
      hexDigit = hexDigit | GetHexDigit(hexChar[j]);
      j++;
      hexByteArray[i] = hexDigit & 0xff;
    }
    return hexByteArray;
  };
  
  const GetHexDigit = (value) => {
    return parseInt(value.toString(), 16);
  };
  
exports.createToken = (req, res,next) => {

        const {data} = req.body;
        console.log(data,'objjjjjjjj')
        if (!data.secretKey) {
            return next(new AppError('Please provide secretKey!', 400));
          }
        if (!data.channelId) {
            return next(new AppError('Please provide channel ID!', 400));
          }  
          // if (!data.channelKey) {
          //   return next(new AppError('Please provide channel Key!', 400));
          // }    
          if (!data.keyWrapAlgorithm || !data.encryptionAlg) {
            return next(new AppError('Please provide proper algorithms!', 400));
          }  

        const requestDate = new Date().toISOString();
        const key = convertHexToSignedByteArray(data.secretKey);
        const baseKey = Buffer.from(key).toString("base64");
        let payload;
        if(data.userName){
          if(data.channelKey){
            payload = {
              channelKey:data.channelKey,
              channelId: data.channelId,
              requestDate: requestDate,
              userName: data.userName
            };
          }else{
            payload = {
              channelId: data.channelId,
              requestDate: requestDate,
              userName: data.userName
            };
          }

        }else{
             payload = {
                channelKey:data.channelKey,
                channelId: data.channelId,
                requestDate: requestDate,
              };
        }

        const keyWrapAlg = data.keyWrapAlgorithm;
        const encryptionAlg = data.encryptionAlg;
      
        const token = jwt.generate(keyWrapAlg, encryptionAlg, payload, baseKey);
        console.log(token);
        res.status(200).json({
          status: "success",
          statusCode: 200,
          results: {
            requestDate: requestDate,
            identityKey: token
          },
        });
}